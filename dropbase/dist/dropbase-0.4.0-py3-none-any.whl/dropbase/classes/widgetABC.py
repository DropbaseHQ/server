from abc import ABC


class WidgetABC(ABC):
    def __init__(self, **kwargs):
        pass
