import re

FILE_NAME_REGEX = re.compile(r"^[A-Za-z0-9_.]+$")
