import re

FILE_NAME_REGEX = re.compile(r"^[A-Za-z0-9_.]+$")
INFER_TYPE_SAMPLE_SIZE = 10
