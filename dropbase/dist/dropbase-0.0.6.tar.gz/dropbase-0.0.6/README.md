# Dropbase Helper Library

Helper package for Dropbase internal app builder.

# About Dropbase

Dropbase helps you build internal web apps with Python. The Dropbase self-hosted Worker securely interacts with your data within your own infra.
